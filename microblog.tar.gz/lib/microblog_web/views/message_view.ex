defmodule MicroblogWeb.MessageView do
  use MicroblogWeb, :view
end
