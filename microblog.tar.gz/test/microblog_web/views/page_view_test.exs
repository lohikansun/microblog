defmodule MicroblogWeb.PageViewTest do
  use MicroblogWeb.ConnCase, async: true
end
